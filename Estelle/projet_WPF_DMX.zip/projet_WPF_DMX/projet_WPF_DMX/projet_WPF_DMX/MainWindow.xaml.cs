﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net; // ajouter pour socket
using System.Net.Sockets; // ajouter pour socket
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using VPackage.Network;

namespace projet_WPF_DMX
{
    public partial class MainWindow : Window
    {
        Client client;

        byte red_value = 0;
        byte blue_value = 0;
        byte green_value = 0;
        public MainWindow()
        {
            InitializeComponent();
            // System.Diagnostics.Debug.WriteLine("Couleur par défaut pour l'ellipse", ellipse_couleur.Fill);
            System.Diagnostics.Debug.WriteLine("Couleur par défaut pour le panel", panel_couleur.Background);
            // ellipse_couleur.Fill = new SolidColorBrush(Color.FromRgb(this.red_value, this.green_value, this.blue_value));
            panel_couleur.Background = new SolidColorBrush(Color.FromRgb(this.red_value, this.green_value, this.blue_value));
            client = new Client("10.129.21.245", 5000); // pour test avec prog Better
            // client.Send("Hello"); 
        }
        private void Quitter_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
        private void btnEffacer_Click(object sender, RoutedEventArgs e)
        {
            
        }
        private void btn_valider_Click(object sender, RoutedEventArgs e)
        {

        }
        private void ouvrirMenu_Click(object sender, RoutedEventArgs e)
        {
            Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();
            dlg.FileName = "Document"; // Default file name
            dlg.DefaultExt = ".text"; // Default file extension
            dlg.Filter = "Text documents (.txt)|*.txt"; // Filter files by extension

            // Show save file dialog box
            Nullable<bool> result = dlg.ShowDialog();

            // Process save file dialog box results
            if (result == true)
            {
                // Save document
                string filename = dlg.FileName;
            }
        }
        private void slider_rouge_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            this.red_value = System.Convert.ToByte(System.Math.Floor(e.NewValue));
            this.changer_couleur_panel();
        }
        private void slider_vert_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            this.green_value = System.Convert.ToByte(System.Math.Floor(e.NewValue));
            this.changer_couleur_panel();
        }
        private void slider_bleu_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            this.blue_value = System.Convert.ToByte(System.Math.Floor(e.NewValue));
            this.changer_couleur_panel();
        }
        private void changer_couleur_panel()
        {
            // ellipse_couleur.Fill = new SolidColorBrush(Color.FromRgb(this.red_value, this.green_value, this.blue_value));
            panel_couleur.Background = new SolidColorBrush(Color.FromRgb(this.red_value, this.green_value, this.blue_value));
        }
        private void MenuEnvoyer_Click(object sender, RoutedEventArgs e)
        {
            //int ServerPort = 5000; // numero du port
            string msg = "RED=" + red_value + ";BLUE=" + blue_value + ";GREEN=" + green_value + ";CIBLE=LYRE;INTENSITY=255";
            try
            {
                //string ipscan = "10.129.21.245"; // IP serveur poste Alexis
                //string iploc = "10.129.22.40"; // IP poste local (moi)
                //serverSocket.Start();
                client.Send(msg);
                Console.WriteLine(" >> Server Started");
            }
            catch (SocketException s)
            {
                Console.WriteLine("SocketException caught!!!");
                Console.WriteLine("Source : " + s.Source);
                Console.WriteLine("Message : " + s.Message);
            }
            // Console.ReadKey();
        }
        private void MenuNew_Click(object sender, RoutedEventArgs e)
        {

        }
        private void MenuEnregistrer_Click(object sender, RoutedEventArgs e)
        {
            {
                Microsoft.Win32.SaveFileDialog dlg = new Microsoft.Win32.SaveFileDialog();
                dlg.FileName = "Document"; // Default file name
                dlg.DefaultExt = ".text"; // Default file extension
                dlg.Filter = "Text documents (.txt)|*.txt"; // Filter files by extension

                // Show save file dialog box
                Nullable<bool> result = dlg.ShowDialog();

                // Process save file dialog box results
                if (result == true)
                {
                    // Save document
                    string filename = dlg.FileName;
                }
            }
        }
    }       
}